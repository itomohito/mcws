<!--footer-->
    <div class="footer">
       <p>All rights Reserved 2020 &copy; Gulmira_mua Beauty salon </p>
    </div>
        <!--//footer-->  
		